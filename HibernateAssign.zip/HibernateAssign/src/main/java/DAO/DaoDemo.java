package DAO;
import java.util.Iterator;
import java.util.List;

import org.hibernate.*;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import DTO.DTODemo;
public class DaoDemo
{
		static Configuration cfg=new Configuration();
		static SessionFactory sf=cfg.configure().buildSessionFactory();
		static Session ss=sf.openSession();
		static DTODemo pojo=new DTODemo();
		static Transaction tx=ss.beginTransaction();

public void saveData(DTODemo d)
{
	ss.save(d);
	tx.commit();
}
public void deleteData(int id) {
	Query qry = ss.createQuery("delete from DTODemo p where p.bookId=?");
    qry.setParameter(0,id);
     int res = qry.executeUpdate();
     tx.commit();
     System.out.println("deleted successfully executed....");
}
public void getBookById(int id) {
	Query q=ss.createQuery("from DTODemo p where p.bookId=?");
    q.setParameter(0,id);
	List stud=q.list();
	Iterator it=stud.iterator();
	while(it.hasNext())
	{
		pojo=(DTODemo)it.next();
		System.out.println(pojo.getBookId());
		System.out.println(pojo.getBookName());
		System.out.println(pojo.getAuthor());
		System.out.println(pojo.getPrice());
		System.out.println(pojo.getPublication());
		System.out.println("-----------------------");
	}
}
public void updatePrice(int id,String price) {
	Query qry = ss.createQuery("update DTODemo p set p.price=? where p.bookId=?");
	qry.setParameter(0, price);
    qry.setParameter(1,id);
     int res = qry.executeUpdate();
     tx.commit();
     System.out.println("price updated successfully....");
}
}
