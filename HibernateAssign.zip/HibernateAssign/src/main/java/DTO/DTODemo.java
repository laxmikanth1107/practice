package DTO;
import javax.persistence.*;
@Entity
@Table(name="book")
public class DTODemo
{
@Id
@Column(name="bookId")
int bookId;
@Column(name="bookName")
String bookName;
@Column(name="author")
String author;
@Column(name="price")
String price;
@Column(name="publication")
String publication;


public int getBookId() {
	return bookId;
}


public void setBookId(int bookId) {
	this.bookId = bookId;
}


public String getBookName() {
	return bookName;
}


public void setBookName(String bookName) {
	this.bookName = bookName;
}


public String getAuthor() {
	return author;
}


public void setAuthor(String author) {
	this.author = author;
}


public String getPrice() {
	return price;
}


public void setPrice(String price) {
	this.price = price;
}


public String getPublication() {
	return publication;
}


public void setPublication(String publication) {
	this.publication = publication;
}


@Override
public String toString() {
	return "DTODemo [bookId=" + bookId + ", bookName=" + bookName + ", author=" + author + ", publication="+publication+", price="+publication+"]";
}


}
