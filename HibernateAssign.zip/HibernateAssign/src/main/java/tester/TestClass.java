package tester;
import DAO.DaoDemo;
import DTO.DTODemo;
import java.util.*;
public class TestClass 
{
public static void main(String[] args) 
{
	Scanner sc=new Scanner(System.in);
	System.out.println("choose your option:");
	System.out.println("1.Add Book ");
	System.out.println("2.Update Book");
	System.out.println("3.Delete Book");
	System.out.println("4.Search for a Book");
	System.out.println("5.Exit");
	System.out.println("Enter Your choice:");
	int ch=sc.nextInt();
	sc.nextLine();
	switch(ch) {
	case 1:
		DTODemo obj=new DTODemo();
		System.out.println("Enter Book Id:");
		obj.setBookId(sc.nextInt());
		sc.nextLine();
		System.out.println("Enter Book Name:");
		obj.setBookName(sc.nextLine());
		System.out.println("Enter Author name:");
		obj.setAuthor(sc.nextLine());
		System.out.println("Enter Book price:");
		obj.setPrice(sc.nextLine());
		System.out.println("Enter Publication name:");
		obj.setPublication(sc.nextLine());
		System.out.println(obj);

		DaoDemo obj1=new DaoDemo();
		obj1.saveData(obj);
		break;
		
	case 2:
		DaoDemo obj4=new DaoDemo();
		System.out.println("Enter Book Id:");
		int id2=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter Book price:");
		String price=sc.nextLine();
		obj4.updatePrice(id2,price);
		break;
	case 3:
		System.out.println("Enter Book Id:");
		int id=sc.nextInt();
		sc.nextLine();
		DaoDemo obj2=new DaoDemo();
		obj2.deleteData(id);
		break;
	case 4:
		System.out.println("Enter Book Id:");
		int id1=sc.nextInt();
		sc.nextLine();
		DaoDemo obj3=new DaoDemo();
		obj3.getBookById(id1);
		break;
	case 5:
		return;
		
	default:System.out.println("Enter the choice between (1-5) only:");
	}
//DTODemo obj=new DTODemo();
//obj.setBookId(1111);
//obj.setBookName("Python");
//obj.setAuthor("Van Rossum");
//obj.setPrice("1999");
//obj.setPublication("original");
//System.out.println(obj);
//
//DaoDemo obj1=new DaoDemo();
//obj1.saveData(obj);
}
}
