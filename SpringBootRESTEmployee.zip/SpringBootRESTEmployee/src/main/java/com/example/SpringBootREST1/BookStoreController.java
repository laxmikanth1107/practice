package com.example.SpringBootREST1;
import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class BookStoreController 
{
@Autowired
private EmployeeService empservice;
@GetMapping("/employees")
public List<Employee> getAllBook()
{
	List<Employee> allemp=empservice.getAllEmployee();
	return allemp;
}

@GetMapping("/employees/{eid}")
public Employee getBookById(@PathVariable int eid)
{
	Employee empDetails=empservice.getEmployeeById(eid);
	return empDetails;
	}
@RequestMapping(method=RequestMethod.POST, value="/employees")
public void addEmployee(@RequestBody Employee e)
{
	empservice.addEmployee(e);
}

@RequestMapping(method=RequestMethod.PUT, value="/employees/{eid}")
public void editEmployee(@RequestBody Employee e,@PathVariable int eid)
{
	empservice.editEmployee(e,eid);
}

@RequestMapping(method=RequestMethod.DELETE, value="/employees/{eid}")
public void deleteEmployee(@RequestBody Employee e,@PathVariable int eid)
{
	empservice.deleteEmployee(eid);
}

}