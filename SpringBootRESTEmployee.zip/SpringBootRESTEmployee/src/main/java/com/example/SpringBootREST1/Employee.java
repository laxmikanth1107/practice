package com.example.SpringBootREST1;

public class Employee {
	private int eid;
	private String name;
	private String dept;
	private String gender;
	private int salary;
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", name=" + name + ", dept=" + dept + ", gender=" + gender + ", salary="
				+ salary + "]";
	}
	public Employee(int eid, String name, String dept, String gender, int salary) {
		this.eid = eid;
		this.name = name;
		this.dept = dept;
		this.gender = gender;
		this.salary = salary;
	}
	
	
}
