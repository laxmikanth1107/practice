package com.example.SpringBootREST1;
import java.util.*;
import org.springframework.stereotype.Component;
@Component
public class EmployeeService implements IEmployeeService
{
	private static List<Employee> employees = new ArrayList<Employee>();
	static
	{
		Employee e1=new Employee(1,"Ram","Admin", "male",56900);
		Employee e2=new Employee(2,"Bob","HR", "female",70000);
		Employee e3=new Employee(3,"Jhon","Training", "male",35000);
		employees.add(e1);
		employees.add(e2);
		employees.add(e3);
		}
	public void addEmployee(Employee e)
	{
		employees.add(e);	 
		}

	public void editEmployee(Employee e, int eid) 
	{
	Employee record= getEmployeeById(eid); 
	employees.remove(record);
		e.setEid(eid);
		employees.add(e);
	}

	public boolean deleteEmployee(int eid) {
	 Employee record = getEmployeeById(eid);
	 employees.remove(record);
		return Boolean.TRUE;
	}

	public Employee getEmployeeById(int eid) 
	{
			return employees.stream().filter(b ->b.getEid() == eid).findFirst().get();
	}

	public List<Employee> getAllEmployee()
	{
		return employees;
	}

}