package com.example.SpringBootREST1;
import java.util.List;

public interface IEmployeeService 
{
public void addEmployee(Employee e);
public void editEmployee(Employee e,int eid);
public boolean deleteEmployee(int eid);
public Employee getEmployeeById(int eid);
public List<Employee> getAllEmployee();

}