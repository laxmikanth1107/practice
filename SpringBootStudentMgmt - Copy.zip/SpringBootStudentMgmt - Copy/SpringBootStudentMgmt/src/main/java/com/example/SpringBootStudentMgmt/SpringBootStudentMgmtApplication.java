package com.example.SpringBootStudentMgmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootStudentMgmtApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootStudentMgmtApplication.class, args);
	}

}
