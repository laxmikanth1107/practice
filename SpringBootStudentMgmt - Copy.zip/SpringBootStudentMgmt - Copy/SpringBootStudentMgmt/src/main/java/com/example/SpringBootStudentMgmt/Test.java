package com.example.SpringBootStudentMgmt;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class Test 
{
	@Autowired
	private JdbcTemplate jt;
	
	
	@GetMapping("/s1")
	public String showLogin()
	{
		return "login";
	}
	
	@GetMapping("/s2")
	public String showRegistration()
	{
		return "register";
	}
	
	@GetMapping("/s3")
	public String showHome()
	{
		return "home";
	}
	
	@GetMapping("/s4")
	public String showStudent()
	{
		return "student";
	}
	
	@GetMapping("/s5")
	public String showBook2()
	{
		return "employee";
	}
	
	@GetMapping("/s6")
	public String showContact()
	{
		return "department";
	}
	
	@GetMapping("/s7")
	public String showFeedback()
	{
		return "subject";
	}
	@GetMapping("/s8")
	public String showInsertStudent()
	{
		return "student1";
	}
	@GetMapping("/s10")
	public String showlogin1()
	{
		return "login1";
	}
	/* Middleware to Backend */
	
	@RequestMapping("/reg")
	public String doRegistration(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		String a=req.getParameter("t1");
		String b=req.getParameter("t2");
		String c=req.getParameter("t3");
		String d=req.getParameter("t4");
		
		
		String sql="insert into login values(?,?,?,?)";
		jt.update(sql,a,b,c,d);
		System.out.println("row inserted");
		return "login";
		
	}
	@RequestMapping("/stuIn")
	public String doInsertStudent(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		String a=req.getParameter("t7");
		String b=req.getParameter("t8");
		String c=req.getParameter("t9");
		String d=req.getParameter("t10");
		String e=req.getParameter("t11");

		
		
		String sql="insert into student values(?,?,?,?,?)";
		jt.update(sql,a,b,c,d,e);
		System.out.println("row inserted");
		return "success";
		
	}
	
	    @RequestMapping("/ver")
	    public String doVerify(HttpServletRequest req) {
	        String username = req.getParameter("t5"); // username field
	        String password = req.getParameter("t6"); // entered password

//	        String sql = "SELECT password FROM login WHERE username = ?";
//
//	        try {
//	            String dbPassword = jt.queryForObject(sql, String.class, username);
//
//	            if (dbPassword != null && dbPassword.equals(password)) {
//	                return "home"; // success page
//	            } else {
//	                return "login";   // back to login page
//	            }
//	        } catch (Exception e) {
//	            return "login"; // user not found or error
//	        }
	        if(username.equals("admin")&& password.equals("0000")) {
	        	return "home";
	        }
	        else {
	        	return "login";
	        }
	    }



	
	@RequestMapping("/feed")
	public String doFeedback(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		String a=req.getParameter("t7");
		String b=req.getParameter("t8");
		String c=req.getParameter("t9");
		
		String sql="insert into feedback values(?,?,?)";
		jt.update(sql,a,b,c);
		System.out.println("row inserted");
		return "s1";
	}
	
	@RequestMapping("/bk")
	public String doBook(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		String a=req.getParameter("t10");
		
		String sql="insert into doctor values(?)";
		jt.update(sql,a);
		System.out.println("row inserted");
		return "success";
	}
	
	@RequestMapping("/bk1")
	public String doBook1(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		String a=req.getParameter("t11");
		String b=req.getParameter("t12");
		String c=req.getParameter("t13");
		String d=req.getParameter("t14");
		String e=req.getParameter("t15");
		String f=req.getParameter("t16");
		String g=req.getParameter("t17");
		String h=req.getParameter("t18");

		
		String sql="insert into bed values(?,?,?,?,?,?,?,?)";
		jt.update(sql,a,b,c,d,e,f,g,h);
		System.out.println("row inserted");
		return "success";
	}
	
	@RequestMapping("/bk2")
	public String doBook2(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		String a=req.getParameter("t19");
		String b=req.getParameter("t20");
		String c=req.getParameter("t21");
		String d=req.getParameter("t22");
		String e=req.getParameter("t23");
		String f=req.getParameter("t24");
		String g=req.getParameter("t25");

		
		String sql="insert into ambulance values(?,?,?,?,?,?,?)";
		jt.update(sql,a,b,c,d,e,f,g);
		System.out.println("row inserted");
		return "success";
	}
	
	
}
