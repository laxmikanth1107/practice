package com.example.SpringBootStudentMgmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootStudentMgmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
